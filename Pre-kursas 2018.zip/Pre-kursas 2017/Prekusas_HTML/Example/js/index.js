function testas() {
	var x = window.getComputedStyle(document.body, null);
	x = x.getPropertyValue("background-image");
	console.log(x);
	if(x != 'none') {
		alert('Nesutvarkytas fonas');
		return false;
	}

	x = window.getComputedStyle(document.getElementsByTagName('h1')[0], null);
	x = x.getPropertyValue("color");

	if(x == 'rgb(255, 192, 203)') {
		alert("Labas vis dar rozinis");
		return false;
	}

	x = window.getComputedStyle(document.getElementsByTagName('ul')[0], null);
	x = x.getPropertyValue("font-size");
	
	if(x == '60px') {
		alert('Lenteles tekstas per didelis');
		return false;
	}

	x = document.getElementsByTagName('li').length;

	if(x < 4) {
		alert('Kazkas ne taip su lentele');
		return false;
	}

	x = document.getElementsByTagName('a')[0].innerHTML.length;

	if(x == 0) {
		alert('Nuoroda ant mazoko teksto');
		return false;
	}

	x = window.getComputedStyle(document.getElementsByTagName('p')[0], null);

	if(x.getPropertyValue("font-size") == '1px') {
		alert('Paragrafo sriftas mazokas');
		return false;
	}

	x = x.getPropertyValue("visibility");
	if(x == 'hidden') {
		alert('Tekstas tikrai matomas?');
		return false;
	}
	alert('Viskas gerai!');
	return true;
}